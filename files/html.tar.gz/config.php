<?php
	$servername = "localhost";
	$username = "dbuser";
	$password = "password";
	$dbname = "Staff";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>