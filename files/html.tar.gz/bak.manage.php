<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      
      $myusername = mysqli_real_escape_string($conn, $_POST['username']);
      $mypassword1 = mysqli_real_escape_string($conn, $_POST['password']);
	  
	  $mypassword = md5($mypassword1);
      
      $sql = "SELECT UserID FROM Users WHERE Username = '$myusername' and Password = '$mypassword'";
      $result = mysqli_query($conn, $sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      if($count == 1) {
		 
		 $_SESSION['myusername'] = $myusername;
         header("location: welcome.php");
      }else {
         echo "Your Login Name or Password is invalid";
      }
   }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Example.com - Staff Details - Welcome</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	<div class="wrapper">
		<header>
			<div class="inner">
				Example.com - Staff Details
			</div>
		</header>
		<nav>
			<div class="inner">
				<ul>
					
					<?php
						if ($_SESSION['logged_in_user_name'] == 'admin') {
							echo "<a href=\"index.php\"><li>Home</li></a>";
							echo "<a href=\"display.php\"><li>Display All Records</li></a>";
							echo "<a href=\"search.php\"><li>Search</li></a>";
							//echo "<a href=\"manage.php\"><li>Manage</li></a>";
							echo "<a href=\"addusers.php\"><li>Add Users</li></a>";
							echo "<a href=\"logout.php\"><li>Log Out</li></a>";
						} else {
							echo "<a href=\"index.php\"><li>Home</li></a>";
							echo "<a href=\"display.php\"><li>Display All Records</li></a>";
							echo "<a href=\"search.php\"><li>Search</li></a>";
							echo "<a href=\"manage.php\"><li>Manage</li></a>";
						}
					?>
				</ul>
			</div>
		</nav>
		
		<div class="main">
			<div class="inner">
				<h3>Login to manage records.<?php echo $login_session; ?></h3> 
					
					<?php
					
					if(session_id() == '' || !isset($_SESSION)) {
					  echo "Session is NOT active";
					} else {
						
						echo "Session is active";
					}
					
					
					?>
					<div class="centered">
						<form action="manage.php" method="post">
							<p><strong>Username:</strong><br/>
							<input type="text" name="username"></p>
							<p><strong>Password:</strong><br/>
							<input type="password" name="password"></p>
							<p><input type="submit" value="Submit"></p>
						</form>
						
					</div>
			</div>
		</div>
		
		<br /><br />
		
		<div class="clearfix"></div>
		
		<br />

		<footer>
			<div class="inner">
				<?php
					$file = 'contact-info.php';
					$show_errors = $_SESSION['display_errors'];
					$is_admin = $_SESSION['logged_in_user_name'];
					
					if (($show_errors == 'yes') && ($is_admin == 'admin')) {
						//if ($show_errors == 'yes') {
						if(file_exists($file)) {
							include($file);
						} else {
							echo "File does not exist" . "<br />";
							echo $is_admin;
							$file = $_GET['file'];
							include('directory/' . $file);
						}
					} else {
						
					}
					
				?>
			</div>
		</footer>
	</div>
</body>
</html>