<?php
   include('session.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Example.com - Staff Details - Add Users</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	<div class="wrapper">
		<header>
			<div class="inner">
				Example.com - Staff Details
			</div>
		</header>
		<nav>
			<div class="inner">
				<ul>
					<?php
						if ($_SESSION['logged_in_user_name'] == 'admin') {
							echo "<a href=\"index.php\"><li>Home</li></a>";
							echo "<a href=\"display.php\"><li>Display All Records</li></a>";
							echo "<a href=\"search.php\"><li>Search</li></a>";
							echo "<a href=\"manage.php\"><li>Manage</li></a>";
							echo "<a href=\"addrecord.php\"><li>Add Record</li></a>";
							echo "<a href=\"logout.php\"><li>Log Out</li></a>";
						} else {
							echo "<a href=\"index.php\"><li>Home</li></a>";
							echo "<a href=\"display.php\"><li>Display All Records</li></a>";
							echo "<a href=\"search.php\"><li>Search</li></a>";
							echo "<a href=\"manage.php\"><li>Manage</li></a>";
						}
					?>
				</ul>
			</div>
		</nav>
		
		<div class="main">
			<div class="inner">
				<h3>Add Record</h3> 
				<div class="main">
					<div class="inner">
							<form action="addrecorddb.php" method="post">
								<p><strong>Firstname:</strong><br/>
								<input type="text" name="firstname"></p>
								<p><strong>Lastname:</strong><br/>
								<input type="text" name="lastname"></p>
								<p><strong>Position:</strong><br/>
								<input type="text" name="position"></p>
								<p><strong>Phone No:</strong><br/>
								<input type="text" name="phone"></p>
								<p><strong>Email:</strong><br/>
								<input type="text" name="email"></p>
								<p><input type="submit" value="Submit"></p>
							</form>
					</div>
				</div>
				
				<button class="btnfloat" onclick="goBack()">Go Back</button>
					<script>
					function goBack() {
					  window.history.back();
					}
					</script>
			</div>
		</div>
		
		<br /><br />
		
		<div class="clearfix"></div>
		
		<br />

		<footer>
			<div class="inner">
				<?php
					$file = 'contact-info.php';
					$show_errors = $_SESSION['display_errors'];
					
					if ($show_errors == 'yes') {
						if(file_exists($file)) {
							include($file);
						} else {
							echo "File does not exist" . "<br />";
							$file = $_GET['file'];
							include('directory/' . $file);
						}
					} else {
						
					}
					
				?>
			</div>
		</footer>
	</div>
</body>
</html>