<?php
   include('session.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Example.com - Staff Details - Logout</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	<div class="wrapper">
		<header>
			<div class="inner">
				Example.com - Staff Details
			</div>
		</header>
		<nav>
			<div class="inner">
					<?php
						if ($_SESSION['logged_in_user_name'] == 'admin') {
							echo "<a href=\"index.php\"><li>Home</li></a>";
							echo "<a href=\"display.php\"><li>Display All Records</li></a>";
							echo "<a href=\"search.php\"><li>Search</li></a>";
							echo "<a href=\"manage.php\"><li>Manage</li></a>";
							echo "<a href=\"addrecord.php\"><li>Add Record</li></a>";
							echo "<a href=\"logout.php\"><li>Log Out</li></a>";
						} else {
							echo "<a href=\"index.php\"><li>Home</li></a>";
							echo "<a href=\"display.php\"><li>Display All Records</li></a>";
							echo "<a href=\"search.php\"><li>Search</li></a>";
							echo "<a href=\"manage.php\"><li>Manage</li></a>";
						}
					?>
			</div>
		</nav>
		
		<div class="main">
			<div class="inner">
				<h3>Logout <?php echo $login_session; ?></h3> 

					<?php
					   session_start();
					   
					   if(session_destroy()) {
						  header("Location: index.php");
					   }
					?>
				
				<button onclick="goBack()">Go Back</button>
					<script>
					function goBack() {
					  window.history.back();
					}
					</script>
			</div>
		</div>

		<footer>
			<div class="inner">
				<?php
					$file = 'contact-info.php';
					$show_errors = $_SESSION['display_errors'];
					
					if ($show_errors == 'yes') {
						if(file_exists($file)) {
							include($file);
						} else {
							echo "File does not exist" . "<br />";
							$file = $_GET['file'];
							include('directory/' . $file);
						}
					} else {
						
					}
					
				?>
			</div>
		</footer>
	</div>
</body>
</html>