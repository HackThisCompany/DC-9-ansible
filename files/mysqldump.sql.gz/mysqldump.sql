-- MySQL dump 10.17  Distrib 10.3.17-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: users
-- ------------------------------------------------------
-- Server version	10.3.17-MariaDB-0+deb10u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `users`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `users` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `users`;

--
-- Table structure for table `UserDetails`
--

DROP TABLE IF EXISTS `UserDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserDetails` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserDetails`
--

LOCK TABLES `UserDetails` WRITE;
/*!40000 ALTER TABLE `UserDetails` DISABLE KEYS */;
INSERT INTO `UserDetails` VALUES (1,'Mary','Moe','marym','3kfs86sfd','2019-12-29 06:58:26'),(2,'Julie','Dooley','julied','468sfdfsd2','2019-12-29 06:58:26'),(3,'Fred','Flintstone','fredf','4sfd87sfd1','2019-12-29 06:58:26'),(4,'Barney','Rubble','barneyr','RocksOff','2019-12-29 06:58:26'),(5,'Tom','Cat','tomc','TC&TheBoyz','2019-12-29 06:58:26'),(6,'Jerry','Mouse','jerrym','B8m#48sd','2019-12-29 06:58:26'),(7,'Wilma','Flintstone','wilmaf','Pebbles','2019-12-29 06:58:26'),(8,'Betty','Rubble','bettyr','BamBam01','2019-12-29 06:58:26'),(9,'Chandler','Bing','chandlerb','UrAG0D!','2019-12-29 06:58:26'),(10,'Joey','Tribbiani','joeyt','Passw0rd','2019-12-29 06:58:26'),(11,'Rachel','Green','rachelg','yN72#dsd','2019-12-29 06:58:26'),(12,'Ross','Geller','rossg','ILoveRachel','2019-12-29 06:58:26'),(13,'Monica','Geller','monicag','3248dsds7s','2019-12-29 06:58:26'),(14,'Phoebe','Buffay','phoebeb','smellycats','2019-12-29 06:58:26'),(15,'Scooter','McScoots','scoots','YR3BVxxxw87','2019-12-29 06:58:26'),(16,'Donald','Trump','janitor','Ilovepeepee','2019-12-29 06:58:26'),(17,'Scott','Morrison','janitor2','Hawaii-Five-0','2019-12-29 06:58:28');
/*!40000 ALTER TABLE `UserDetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `Staff`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `Staff` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `Staff`;

--
-- Table structure for table `StaffDetails`
--

DROP TABLE IF EXISTS `StaffDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StaffDetails` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `position` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StaffDetails`
--

LOCK TABLES `StaffDetails` WRITE;
/*!40000 ALTER TABLE `StaffDetails` DISABLE KEYS */;
INSERT INTO `StaffDetails` VALUES (1,'Mary','Moe','CEO','46478415155456','marym@example.com','2019-05-01 07:32:00'),(2,'Julie','Dooley','Human Resources','46457131654','julied@example.com','2019-05-01 07:32:00'),(3,'Fred','Flintstone','Systems Administrator','46415323','fredf@example.com','2019-05-01 07:32:00'),(4,'Barney','Rubble','Help Desk','324643564','barneyr@example.com','2019-05-01 07:32:00'),(5,'Tom','Cat','Driver','802438797','tomc@example.com','2019-05-01 07:32:00'),(6,'Jerry','Mouse','Stores','24342654756','jerrym@example.com','2019-05-01 07:32:00'),(7,'Wilma','Flintstone','Accounts','243457487','wilmaf@example.com','2019-05-01 07:32:00'),(8,'Betty','Rubble','Junior Accounts','90239724378','bettyr@example.com','2019-05-01 07:32:00'),(9,'Chandler','Bing','President - Sales','189024789','chandlerb@example.com','2019-05-01 07:32:00'),(10,'Joey','Tribbiani','Janitor','232131654','joeyt@example.com','2019-05-01 07:32:00'),(11,'Rachel','Green','Personal Assistant','823897243978','rachelg@example.com','2019-05-01 07:32:00'),(12,'Ross','Geller','Instructor','6549638203','rossg@example.com','2019-05-01 07:32:00'),(13,'Monica','Geller','Marketing','8092432798','monicag@example.com','2019-05-01 07:32:00'),(14,'Phoebe','Buffay','Assistant Janitor','43289079824','phoebeb@example.com','2019-05-01 07:32:02'),(15,'Scooter','McScoots','Resident Cat','454786464','scoots@example.com','2019-05-01 10:16:33'),(16,'Donald','Trump','Replacement Janitor','65464646479741','janitor@example.com','2019-12-22 17:11:39'),(17,'Scott','Morrison','Assistant Replacement Janitor','47836546413','janitor2@example.com','2019-12-23 17:41:04');
/*!40000 ALTER TABLE `StaffDetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `UserID` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,'admin','856f5de590ef37314e7c3bdf6f8a66dc');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-12  8:39:45
